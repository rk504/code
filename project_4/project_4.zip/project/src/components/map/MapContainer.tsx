import { Map } from './Map';

export function MapContainer() {
  return (
    <div className="w-full h-full">
      <Map />
    </div>
  );
}