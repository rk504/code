import { Suspense } from 'react'
import dynamic from 'next/dynamic'
import Header from './components/Header'
import Sidebar from './components/Sidebar'
import OpportunityList from './components/OpportunityList'
import EmailSignup from './components/EmailSignup'
import { getOpportunities } from '../lib/data'

// Dynamically import the Map component with no SSR
const Map = dynamic(() => import('./components/Map'), { 
  ssr: false,
  loading: () => <div className="w-full h-full flex items-center justify-center">Loading map...</div>
})

export default function Home() {
  const opportunities = getOpportunities()

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 flex flex-col">
          <div className="flex-1 flex">
            <div className="w-1/2 overflow-y-auto">
              <OpportunityList opportunities={opportunities} />
            </div>
            <div className="w-1/2 relative">
              <Suspense fallback={<div className="w-full h-full flex items-center justify-center">Loading map...</div>}>
                <Map opportunities={opportunities} />
              </Suspense>
            </div>
          </div>
          <EmailSignup />
        </main>
      </div>
    </div>
  )
}

