'use client'

import { useState, useEffect } from 'react'
import dynamic from 'next/dynamic'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

const MapContainer = dynamic(() => import('react-leaflet').then(mod => mod.MapContainer), { ssr: false })
const TileLayer = dynamic(() => import('react-leaflet').then(mod => mod.TileLayer), { ssr: false })
const Marker = dynamic(() => import('react-leaflet').then(mod => mod.Marker), { ssr: false })
const Popup = dynamic(() => import('react-leaflet').then(mod => mod.Popup), { ssr: false })

// Custom marker icon
const customIcon = L.divIcon({
  className: 'custom-icon',
  html: `<div class="marker-pin"></div>`,
  iconSize: [30, 30],
  iconAnchor: [15, 30],
  popupAnchor: [0, -30]
})

export default function Map({ opportunities }) {
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  if (!isClient) return null

  return (
    <>
      <style jsx global>{`
        .custom-icon {
          background-color: #3b82f6;
          border-radius: 50%;
          width: 30px !important;
          height: 30px !important;
          display: flex;
          justify-content: center;
          align-items: center;
          color: white;
          font-weight: bold;
        }
        .marker-pin {
          width: 30px;
          height: 30px;
          border-radius: 50% 50% 50% 0;
          background: #3b82f6;
          position: absolute;
          transform: rotate(-45deg);
          left: 50%;
          top: 50%;
          margin: -15px 0 0 -15px;
        }
        .marker-pin::after {
          content: '';
          width: 24px;
          height: 24px;
          margin: 3px 0 0 3px;
          background: #fff;
          position: absolute;
          border-radius: 50%;
        }
      `}</style>
      <MapContainer 
        center={[40.7128, -74.0060]} 
        zoom={11} 
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {opportunities.map((opportunity) => (
          <Marker
            key={opportunity.id}
            position={[opportunity.latitude, opportunity.longitude]}
            icon={customIcon}
          >
            <Popup>
              <div>
                <h3 className="font-semibold">{opportunity.title}</h3>
                <p className="text-sm">{opportunity.organization}</p>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </>
  )
}

