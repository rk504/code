'use client'

import { useState } from 'react'
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"

export default function EmailSignup() {
  const [email, setEmail] = useState('')
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the email to your backend
    console.log('Submitted email:', email)
    toast({
      title: "Thanks for signing up!",
      description: "We'll keep you updated on new volunteer opportunities.",
    })
    setEmail('')
  }

  return (
    <div className="bg-blue-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
          Stay updated on volunteer opportunities
        </h2>
        <p className="mt-4 text-lg text-gray-500">
          Sign up for our newsletter to receive the latest volunteer opportunities in your area.
        </p>
        <form onSubmit={handleSubmit} className="mt-8 sm:flex justify-center">
          <Input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="w-full px-5 py-3 border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:max-w-xs rounded-md"
          />
          <div className="mt-3 sm:mt-0 sm:ml-3">
            <Button type="submit" className="w-full flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:w-auto">
              Sign up
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}

